Thank you for downloading my fantasy bow assets. ^^

Each bow sprite has 32x32 pixel resolution, I suggest you to use png format when importing
the assets in your game engine, I also seperated arrows in aseprite files in case if you need arrowless ones. 

You can tweak and edit the assets using aseprite files, if you have aseprite installed on your computer.

Feel free to use my assets in your game projects, hope my assets be helpful. 

